print("\x1b[2J\x1b[H")
