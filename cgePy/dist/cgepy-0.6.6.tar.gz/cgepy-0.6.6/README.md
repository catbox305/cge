### cgepy // 6.6
###### A simple graphics engine with no dependencies.
***
cgePy, or cge, is a text-based graphics engine that can operate in the console or terminal.\
Currently with zero dependencies, a simple system that can suit many needs, and easily tweaked settings, cgePy will allow you to turn ideas into reality.
