__version__ = '0.6.6'

def clear():
	print("\x1b[2J\x1b[H")
