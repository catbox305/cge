__version__ = '0.7.0'

def clear():
	print('\033[2J')
	print('\033[0;0H')
