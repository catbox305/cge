__version__ = "0.6.0"
print("\x1b[31mNotice: There is no current development of cgePy to run!")