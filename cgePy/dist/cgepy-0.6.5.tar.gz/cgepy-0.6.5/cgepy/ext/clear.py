__version__ = '0.6.5'

def clear():
	print("\x1b[2J\x1b[H")
