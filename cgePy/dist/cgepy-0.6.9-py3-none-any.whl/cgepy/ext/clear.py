__version__ = '0.6.9'

def clear():
	print('\033[2J]')
	print('\033[0;0H')
