### cgepy // 0.7.1
##### A lightweight 8-bit graphics engine
***
###### Documentation: https://cgepy.github.io/docs
Looking for something simple to use? Want to use a reliable package for once?\
cgepy's got you covered.

Featuring a powerful, but easy-to-use system, you can make fun games with cgepy.\
Though cgepy lacks many things like mouse support and native keyboard support, it is ever growing and will soon have so many features in place of those, while maintaining that same speed and reliablility.
