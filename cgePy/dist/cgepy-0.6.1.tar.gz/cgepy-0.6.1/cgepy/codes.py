INIT = True #DO NOT CHANGE THIS
if INIT == True:
	#Define color variables
	RED='\033[0;41m'
	YELLOW='\033[1;43m'
	ORANGE='\033[0;43'
	GREEN='\033[0;42m'
	BLUE='\033[0;44m'
	CYAN='\033[0;46m'
	MAGENTA='\033[0;45m'
	BLACK='\033[0;40m'
	WHITE='\033[0;47m'
	RESET='\033[0m'
	black = '\033[0;30m'
	red = '\033[0;31m'
	green = '\033[0;32m'
	yellow = '\033[0;33m'
	blue = '\033[0;34m'
	magenta = '\033[0;35m'
	cyan = '\033[0;36m'
	white = '\033[m'

