__version__ = '0.6.8'

def clear():
	print("\x1b[2J\x1b[H")
